import java.util.ArrayList;
import java.util.Iterator;

/**
 * TODO COMPLETE THIS CLASS
 *
 */
public class RecipeList implements ListADT<Recipe> {
    
    // You may use an ArrayList<Recipe> as your internal data structure
    
}
