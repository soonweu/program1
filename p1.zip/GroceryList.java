import java.util.ArrayList;
import java.util.Iterator;

/**
 * TODO COMPLETE THIS CLASS
 *
 */
public class GroceryList implements ListADT<Ingredient>  {

    // you may use an ArrayList<Ingredient> as your internal data structure
    
    
}
